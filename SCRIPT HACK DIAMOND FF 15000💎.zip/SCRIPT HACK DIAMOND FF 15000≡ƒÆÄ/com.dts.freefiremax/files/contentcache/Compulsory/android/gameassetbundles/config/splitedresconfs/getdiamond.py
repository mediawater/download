os.system

hack == if com.dts.freefireth
         else com.dts.freefiremax
        print(hack 15000,DIAMONDS)
id == nano

hack database.garena


send 15000 DIAMOND > id == true